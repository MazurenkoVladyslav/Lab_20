function isValidURL(url) {
    const urlRegex = /^(http|https|ftp):\/\/[\w\-]+(\.[\w\-]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?$/;

    return urlRegex.test(url);
} 
let url1 = "https://www.netflix.com";
let url2 = "ftp://fileserver/documents";
let url3 = "youtube.com";
let url4 = "https://www.youtube.com";
let url5 = "https:/www.instagram.com";
console.log(isValidURL(url1));  
console.log(isValidURL(url2));  
console.log(isValidURL(url3));  
console.log(isValidURL(url4));  
console.log(isValidURL(url5));  
